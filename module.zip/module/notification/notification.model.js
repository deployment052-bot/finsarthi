import mongoose from "mongoose";

const notificationSchema =
  new mongoose.Schema(
    {
      user: {
        type:
          mongoose.Schema.Types.ObjectId,
        ref: "User",
      },

      title: String,

      message: String,
type: {
  type: String,
  enum: [
    "LOAN",
    "KYC",
    "PAYMENT",
    "ACCOUNT",
    "TRANSACTION",
    "EMI",
    "PROMOTION",
    "CREDIT_SCORE",
    "SECURITY",
    "GENERAL"
  ],
  default: "GENERAL"
},
      visible: {
  type: Boolean,
  default: true,
},

      read: {
        type: Boolean,
        default: false,
      },

      data: Object,
    },
    {
      timestamps: true,
    }
  );

export default mongoose.model(
  "Notification",
  notificationSchema
);