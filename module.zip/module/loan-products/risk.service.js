export const generateRiskScore = async (user) => {

  let score = 500;

  if (user.kycVerified)
    score += 100;

  if (user.bankVerified)
    score += 100;

  if (user.mobileVerified)
    score += 50;

  if (user.previousLoanPaid)
    score += 150;

  return score;
};