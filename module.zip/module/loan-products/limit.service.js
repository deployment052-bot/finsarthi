export const calculateLimit = (
  score
) => {

  if (score >= 900)
    return 50000;

  if (score >= 850)
    return 30000;

  if (score >= 800)
    return 20000;

  if (score >= 750)
    return 10000;

  return 2000;
};