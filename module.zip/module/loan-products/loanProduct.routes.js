import express from "express";

import {
  createLoanProduct,
  getLoanProducts,
  getLoanProductById,
  updateLoanProduct,
  deleteLoanProduct,
  toggleLoanProductStatus,
} from "./loanProduct.controller.js";

const router = express.Router();

router.post("/create/loan", createLoanProduct);

router.get("/get", getLoanProducts);

router.get("/:id", getLoanProductById);

router.put("/:id", updateLoanProduct);

router.delete("/:id", deleteLoanProduct);

router.patch("/:id/toggle-status", toggleLoanProductStatus);

export default router;