export const decideLoan = (
 score,
 amount
)=>{

 if(
   score >= 750 &&
   amount <= 10000
 ){
    return {
      approved:true,
      type:"INSTANT"
    };
 }

 if(
   score >= 650 &&
   amount <= 50000
 ){
    return {
      approved:true,
      type:"MANUAL"
    };
 }

 return {
   approved:false,
   reason:"LOW_SCORE"
 };
};