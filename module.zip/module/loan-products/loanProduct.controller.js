import LoanProduct from "./loanProduct.model.js";

// Create Loan Product
export const createLoanProduct = async (req, res) => {
  try {
    const existingProduct = await LoanProduct.findOne({
      code: req.body.code,
    });

    if (existingProduct) {
      return res.status(400).json({
        success: false,
        message: "Loan product code already exists",
      });
    }

    const product = await LoanProduct.create(req.body);

    return res.status(201).json({
      success: true,
      message: "Loan product created successfully",
      data: product,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Get All Loan Products
export const getLoanProducts = async (req, res) => {
  try {
    const products = await LoanProduct.find().sort({
      createdAt: -1,
    });

    return res.status(200).json({
      success: true,
      count: products.length,
      data: products,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Get Single Loan Product
export const getLoanProductById = async (req, res) => {
  try {
    const product = await LoanProduct.findById(req.params.id);

    if (!product) {
      return res.status(404).json({
        success: false,
        message: "Loan product not found",
      });
    }

    return res.status(200).json({
      success: true,
      data: product,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Update Loan Product
export const updateLoanProduct = async (req, res) => {
  try {
    const product = await LoanProduct.findByIdAndUpdate(
      req.params.id,
      req.body,
      {
        new: true,
        runValidators: true,
      }
    );

    if (!product) {
      return res.status(404).json({
        success: false,
        message: "Loan product not found",
      });
    }

    return res.status(200).json({
      success: true,
      message: "Loan product updated successfully",
      data: product,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Delete Loan Product
export const deleteLoanProduct = async (req, res) => {
  try {
    const product = await LoanProduct.findById(req.params.id);

    if (!product) {
      return res.status(404).json({
        success: false,
        message: "Loan product not found",
      });
    }

    await product.deleteOne();

    return res.status(200).json({
      success: true,
      message: "Loan product deleted successfully",
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Enable / Disable Loan Product
export const toggleLoanProductStatus = async (req, res) => {
  try {
    const product = await LoanProduct.findById(req.params.id);

    if (!product) {
      return res.status(404).json({
        success: false,
        message: "Loan product not found",
      });
    }

    product.active = !product.active;

    await product.save();

    return res.status(200).json({
      success: true,
      message: `Loan product ${
        product.active ? "enabled" : "disabled"
      } successfully`,
      data: product,
    });
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};