import LoanApplication
from "../../loan-applications/loanApplication.model.js";

import { getRiskData }
from "./risk.service.js";

import { calculateLimit }
from "./limit.service.js";

export const checkEligibility =
  async (user) => {

    if (!user.kycVerified) {
      return {
        eligible: false,
        reason:
          "KYC_REQUIRED",
      };
    }

    if (!user.bankVerified) {
      return {
        eligible: false,
        reason:
          "BANK_REQUIRED",
      };
    }

    const activeLoans =
      await LoanApplication.countDocuments(
        {
          customer: user._id,
          status: {
            $in: [
              "APPROVED",
              "ACTIVE",
            ],
          },
        }
      );

    if (activeLoans >= 2) {
      return {
        eligible: false,
        reason:
          "MAX_ACTIVE_LOANS",
      };
    }

    const creditData =
      await getRiskData(user);

    const approvedLimit =
      calculateLimit(
        creditData.score
      );

    return {
      eligible: true,

      riskScore:
        creditData.score,

      approvedLimit,

      creditData,
    };
  };