import mongoose from "mongoose";

const loanProductSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },

    code: {
      type: String,
      unique: true,
      required: true,
      uppercase: true,
    },

    type: {
      type: String,
      enum: ["INSTANT", "MANUAL"],
      required: true,
    },

    description: String,

    minAmount: {
      type: Number,
      required: true,
    },

    maxAmount: {
      type: Number,
      required: true,
    },

    minTenure: {
      type: Number,
      required: true,
    },

    maxTenure: {
      type: Number,
      required: true,
    },

    interestRate: {
      type: Number,
      required: true,
    },

    processingFee: {
      type: Number,
      default: 0,
    },

    processingFeeType: {
      type: String,
      enum: ["PERCENTAGE", "FIXED"],
      default: "PERCENTAGE",
    },

    gstPercentage: {
      type: Number,
      default: 18,
    },

    minRiskScore: {
      type: Number,
      default: 700,
    },

    instantDisbursement: {
      type: Boolean,
      default: false,
    },

    requiresPhysicalVerification: {
      type: Boolean,
      default: false,
    },

    maxActiveLoans: {
      type: Number,
      default: 1,
    },

    active: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);

export default mongoose.model(
  "LoanProduct",
  loanProductSchema
);