// import mongoose from "mongoose";

// const loanApplicationSchema = new mongoose.Schema(
//   {
//     applicationId: {
//       type: String,
//       unique: true,
//       required: true,
//       index: true,
//     },

//     user: {
//       type: mongoose.Schema.Types.ObjectId,
//       ref: "User",
//       required: true,
//     },

//     loanProduct: {
//       type: mongoose.Schema.Types.ObjectId,
//       ref: "LoanProduct",
//       required: true,
//     },

//     loanType: {
//       type: String,
//       enum: ["SECURED", "UNSECURED"],
//       required: true,
//     },

//     amount: {
//       type: Number,
//       required: true,
//     },

//     tenure: {
//       type: Number,
//       required: true,
//     },

//     purpose: String,

//     status: {
//       type: String,
//       enum: [
//         "DRAFT",
//         "SUBMITTED",
//         "UNDER_REVIEW",
//         "APPROVED",
//         "REJECTED",
//         "DISBURSED",
//         "CLOSED",
//       ],
//       default: "DRAFT",
//     },
//   },
//   {
//     timestamps: true,
//   }
// );

// export default mongoose.model(
//   "LoanApplication",
//   loanApplicationSchema
// );

import mongoose from "mongoose";

const loanApplicationSchema = new mongoose.Schema(
  {
    applicationId: {
      type: String,
      unique: true,
    },

    customer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    product: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "LoanProduct",
      required: true,
    },

    amount: {
      type: Number,
      required: true,
    },

    tenure: {
      type: Number,
      required: true,
    },

    riskScore: {
      type: Number,
      default: 0,
    },

    approvedLimit: {
      type: Number,
      default: 0,
    },

    status: {
      type: String,
      enum: [
        "SUBMITTED",
        "UNDER_REVIEW",
        "APPROVED",
        "REJECTED",
        "DISBURSED",
        "ACTIVE",
        "CLOSED",
      ],
      default: "SUBMITTED",
    },

    creditData: {
      score: Number,
      activeLoans: Number,
      overdueAmount: Number,
      enquiries: Number,
      source: String,
    },

    remarks: String,
  },
  {
    timestamps: true,
  }
);

export default mongoose.model(
  "LoanApplication",
  loanApplicationSchema
);