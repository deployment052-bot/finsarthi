import LoanApplication from "./loanApplication.model.js";
import LoanProduct from "../loan-products/loanProduct.model.js";

import { checkEligibility }
from "../loan-products/services/eligibility.service.js";

import { getDecision }
from "../loan-products/services/decision.service.js";

export const applyLoan = async (
  req,
  res
) => {
  try {

    const {
      productId,
      amount,
      tenure,
    } = req.body;

    const product =
      await LoanProduct.findById(
        productId
      );

    if (!product) {
      return res.status(404).json({
        success: false,
        message:
          "Loan product not found",
      });
    }

    const eligibility =
      await checkEligibility(
        req.user
      );

    if (!eligibility.eligible) {
      return res.status(400).json({
        success: false,
        message:
          eligibility.reason,
      });
    }

    if (
      amount >
      eligibility.approvedLimit
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Amount exceeds eligible limit",
      });
    }

    const decision =
      getDecision(
        eligibility.riskScore,
        product
      );

    const application =
      await LoanApplication.create({
        customer: req.user._id,

        product: product._id,

        amount,

        tenure,

        riskScore:
          eligibility.riskScore,

        approvedLimit:
          eligibility.approvedLimit,

        creditData:
          eligibility.creditData,

        status:
          decision.status,
      });

    return res.status(201).json({
      success: true,
      message:
        "Loan application submitted",
      data: application,
    });

  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};