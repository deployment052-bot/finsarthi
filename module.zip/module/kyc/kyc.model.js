import mongoose from "mongoose";

const kycSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
      unique: true,
    },

    application: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "LoanApplication",
    },

    // Step 1
    aadhaarNumber: String,
    panNumber: String,

    // Step 2 - Personal Details
    fullName: {
      type: String,
      required: true,
    },

    dob: {
      type: Date,
      required: true,
    },

    email: String,

    fatherName: String,

    motherName: String,

    gender: {
      type: String,
      enum: ["MALE", "FEMALE", "OTHER"],
    },

    occupation: {
      type: String,
      enum: [
        "SALARIED",
        "SELF_EMPLOYED",
        "STUDENT",
        "HOMEMAKER",
        "RETIRED",
        "OTHER",
      ],
    },

    annualIncome: {
      type: String,
      enum: [
        "LESS_THAN_3L",
        "BETWEEN_3L_6L",
        "BETWEEN_6L_12L",
        "ABOVE_12L",
      ],
    },

    addressLine: String,

    city: String,

    state: String,

    pinCode: String,

    method: {
      type: String,
      enum: ["MANUAL", "DIGILOCKER"],
      default: "MANUAL",
    },

    status: {
      type: String,
      enum: [
        "PENDING",
        "UNDER_REVIEW",
        "VERIFIED",
        "REJECTED",
      ],
      default: "PENDING",
    },

    remarks: String,

    verifiedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },

    verifiedAt: Date,
  },
  {
    timestamps: true,
  }
);

export default mongoose.model("KYC", kycSchema);